"use client";

import { AnimatePresence, motion } from "framer-motion";
import {
  Package,
  PackageSearch,
  Pencil,
  Plus,
  Search,
  ShoppingBag,
  ShoppingCart,
  Trash2,
} from "lucide-react";
import { useSearchParams } from "next/navigation";
import { Suspense, useMemo, useState } from "react";
import { toast } from "sonner";
import type { Product } from "@/db/schema";
import {
  EXPIRING_WINDOW_DAYS,
  expiryDays,
  isLowStock,
  productApi,
  refreshAll,
  transactionApi,
  useProducts,
} from "@/lib/api";
import { cn, expiryLabel, formatRupiah, formatShortDate, todayISO } from "@/lib/format";
import { Badge, Button, Card, ConfirmDialog, EmptyState, IconButton, Segmented } from "@/components/ui";
import { ProductModal } from "@/components/product-modal";
import { QuickNumpad } from "@/components/quick-numpad";

type Filter = "semua" | "menipis" | "expired";

function ProductRow({
  product,
  onEdit,
  onDelete,
  onJual,
  onBeli,
}: {
  product: Product;
  onEdit: () => void;
  onDelete: () => void;
  onJual: () => void;
  onBeli: () => void;
}) {
  const low = isLowStock(product);
  const expDays = expiryDays(product);
  const expired = expDays !== null && expDays < 0;
  const expiringSoon = expDays !== null && expDays >= 0 && expDays <= EXPIRING_WINDOW_DAYS;

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.98 }}
      transition={{ type: "spring", stiffness: 320, damping: 30 }}
      className="px-4 py-4 sm:px-5"
    >
      {/* Baris 1: nama + stok */}
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="truncate text-sm font-bold text-stone-900 sm:text-[15px]">{product.name}</p>
          <p className="mt-0.5 text-xs font-medium text-stone-400">
            {product.category} · Min. {product.minStock}
          </p>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          <span
            className={cn(
              "text-2xl font-black tabular-nums",
              product.stock === 0 ? "text-red-500" : low ? "text-amber-600" : "text-stone-800",
            )}
          >
            {product.stock}
          </span>
          <span className="text-sm font-bold text-stone-900 tabular-nums">
            {formatRupiah(product.sellPrice)}
          </span>
        </div>
      </div>

      {/* Badge */}
      <div className="mt-2 flex flex-wrap gap-1.5">
        {product.stock === 0 ? (
          <Badge tone="red">Stok habis</Badge>
        ) : low ? (
          <Badge tone="amber">Stok menipis</Badge>
        ) : null}
        {expired && (
          <Badge tone="red">Expired · {product.expiryDate ? formatShortDate(product.expiryDate) : ""}</Badge>
        )}
        {expiringSoon && (
          <Badge tone={(expDays ?? 99) <= 3 ? "rose" : "amber"}>
            {expiryLabel(expDays!)} · {product.expiryDate ? formatShortDate(product.expiryDate) : ""}
          </Badge>
        )}
      </div>

      {/* Tombol aksi */}
      <div className="mt-3 flex items-center gap-2">
        <button
          onClick={onBeli}
          className="flex h-9 flex-1 cursor-pointer items-center justify-center gap-1.5 rounded-xl border border-stone-200 bg-white text-xs font-bold text-stone-700 transition-all active:scale-[0.97] hover:bg-stone-50"
        >
          <ShoppingCart className="size-3.5" />
          Beli stok
        </button>
        <button
          onClick={onJual}
          className="flex h-9 flex-1 cursor-pointer items-center justify-center gap-1.5 rounded-xl bg-emerald-50 text-xs font-bold text-emerald-700 transition-all active:scale-[0.97] hover:bg-emerald-100"
        >
          <ShoppingBag className="size-3.5" />
          Jual
        </button>
        <IconButton onClick={onEdit} aria-label="Ubah barang">
          <Pencil className="size-4" />
        </IconButton>
        <IconButton onClick={onDelete} aria-label="Hapus barang" className="hover:bg-rose-50 hover:text-rose-600">
          <Trash2 className="size-4" />
        </IconButton>
      </div>
    </motion.div>
  );
}

function BarangInner() {
  const params = useSearchParams();
  const initialFilter = (params.get("filter") ?? "semua") as Filter;
  const [filter, setFilter] = useState<Filter>(
    ["semua", "menipis", "expired"].includes(initialFilter) ? initialFilter : "semua",
  );
  const [query, setQuery] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Product | null>(null);
  const [deleting, setDeleting] = useState<Product | null>(null);
  const [deleteBusy, setDeleteBusy] = useState(false);

  // Numpad
  const [numpad, setNumpad] = useState<{
    open: boolean;
    mode: "jual" | "beli";
    product: Product | null;
  }>({ open: false, mode: "jual", product: null });

  const { products, isLoading } = useProducts();

  const counts = useMemo(() => {
    const menipis = products.filter(isLowStock).length;
    const expiredSoon = products.filter((p) => {
      const d = expiryDays(p);
      return d !== null && d <= EXPIRING_WINDOW_DAYS;
    }).length;
    return { menipis, expiredSoon };
  }, [products]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return products.filter((p) => {
      if (q && !p.name.toLowerCase().includes(q) && !p.category.toLowerCase().includes(q)) return false;
      if (filter === "menipis") return isLowStock(p);
      if (filter === "expired") {
        const d = expiryDays(p);
        return d !== null && d <= EXPIRING_WINDOW_DAYS;
      }
      return true;
    });
  }, [products, query, filter]);

  async function confirmDelete() {
    if (!deleting) return;
    setDeleteBusy(true);
    try {
      await productApi.remove(deleting.id);
      toast.success(`"${deleting.name}" dihapus.`);
      refreshAll();
      setDeleting(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Gagal menghapus barang.");
    } finally {
      setDeleteBusy(false);
    }
  }

  async function handleNumpadConfirm(qty: number, total: number, customNominal?: number) {
    const p = numpad.product;
    if (!p) return;

    if (numpad.mode === "jual") {
      const newStock = Math.max(0, p.stock - qty);
      await Promise.all([
        productApi.update(p.id, { stock: newStock }),
        transactionApi.create({
          type: "income",
          amount: customNominal ?? total,
          note: `Jual ${p.name}${qty > 1 ? ` ×${qty}` : ""}`,
          date: todayISO(),
        }),
      ]);
      toast.success(`✅ Penjualan ${p.name} tercatat!`);
    } else {
      const newStock = p.stock + qty;
      const nominal = total > 0 ? total : qty * p.sellPrice;
      await Promise.all([
        productApi.update(p.id, { stock: newStock }),
        transactionApi.create({
          type: "expense",
          amount: nominal,
          note: `Beli stok ${p.name} ×${qty}`,
          date: todayISO(),
        }),
      ]);
      toast.success(`📦 Stok ${p.name} bertambah jadi ${newStock}!`);
    }

    refreshAll();
    setNumpad((v) => ({ ...v, open: false }));
  }

  const emptyCopy: Record<Filter, { title: string; message: string }> = {
    semua: { title: "Belum ada barang", message: "Tekan tombol Tambah Barang untuk mencatat barang pertamamu." },
    menipis: { title: "Stok aman", message: "Tidak ada barang yang stoknya di bawah batas minimum." },
    expired: { title: "Tidak ada yang expired", message: "Tidak ada barang yang kedaluwarsa dalam 14 hari ke depan." },
  };

  return (
    <div className="flex flex-col gap-5">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight text-stone-900 sm:text-3xl">Barang</h1>
          <p className="mt-1 text-sm font-medium text-stone-500">
            {products.length} jenis barang
            {counts.menipis > 0 && <span className="text-amber-600"> · {counts.menipis} menipis</span>}
            {counts.expiredSoon > 0 && <span className="text-rose-500"> · {counts.expiredSoon} mau expired</span>}
          </p>
        </div>
        <Button
          onClick={() => {
            setEditing(null);
            setModalOpen(true);
          }}
        >
          <Plus className="size-4" strokeWidth={2.6} />
          Tambah Barang
        </Button>
      </div>

      {/* Toolbar */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="relative flex-1 sm:max-w-xs">
          <Search className="pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-stone-400" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Cari barang..."
            className="h-11 w-full rounded-xl border border-stone-200 bg-white pl-10 pr-3 text-sm text-stone-900 placeholder:text-stone-400 transition-colors focus:border-emerald-600 focus:outline-none focus:ring-4 focus:ring-emerald-600/10"
          />
        </div>
        <Segmented<Filter>
          id="filter-barang"
          value={filter}
          onChange={setFilter}
          options={[
            { value: "semua", label: "Semua", count: products.length },
            { value: "menipis", label: "Menipis", count: counts.menipis },
            { value: "expired", label: "Expired", count: counts.expiredSoon },
          ]}
        />
      </div>

      {/* Daftar */}
      <Card className="overflow-hidden p-0">
        {isLoading ? (
          <div className="space-y-3 p-5">
            {[0, 1, 2, 3].map((i) => (
              <div key={i} className="h-20 animate-pulse rounded-xl bg-stone-100" />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          query ? (
            <EmptyState
              icon={PackageSearch}
              title="Tidak ketemu"
              message={`Tidak ada barang yang cocok dengan "${query}".`}
            />
          ) : (
            <EmptyState
              icon={Package}
              title={emptyCopy[filter].title}
              message={emptyCopy[filter].message}
              action={
                filter === "semua" ? (
                  <Button
                    size="sm"
                    onClick={() => {
                      setEditing(null);
                      setModalOpen(true);
                    }}
                  >
                    <Plus className="size-4" />
                    Tambah Barang
                  </Button>
                ) : undefined
              }
            />
          )
        ) : (
          <div className="divide-y divide-stone-100">
            <AnimatePresence initial={false}>
              {filtered.map((p) => (
                <ProductRow
                  key={p.id}
                  product={p}
                  onEdit={() => {
                    setEditing(p);
                    setModalOpen(true);
                  }}
                  onDelete={() => setDeleting(p)}
                  onJual={() => setNumpad({ open: true, mode: "jual", product: p })}
                  onBeli={() => setNumpad({ open: true, mode: "beli", product: p })}
                />
              ))}
            </AnimatePresence>
          </div>
        )}
      </Card>

      {/* Modals */}
      <ProductModal open={modalOpen} onClose={() => setModalOpen(false)} product={editing} />
      <ConfirmDialog
        open={Boolean(deleting)}
        onClose={() => setDeleting(null)}
        onConfirm={confirmDelete}
        loading={deleteBusy}
        title="Hapus Barang"
        message={`Yakin mau hapus "${deleting?.name}"? Data barang ini tidak bisa dikembalikan.`}
      />
      {numpad.product && (
        <QuickNumpad
          open={numpad.open}
          mode={numpad.mode}
          productName={numpad.product.name}
          hargaSatuan={numpad.product.sellPrice}
          stokSaat={numpad.product.stock}
          onClose={() => setNumpad((v) => ({ ...v, open: false }))}
          onConfirm={handleNumpadConfirm}
        />
      )}
    </div>
  );
}

export default function BarangPage() {
  return (
    <Suspense fallback={null}>
      <BarangInner />
    </Suspense>
  );
}
