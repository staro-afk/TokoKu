"use client";

import { AnimatePresence, motion } from "framer-motion";
import {
  ArrowDownRight,
  ArrowUpRight,
  ChevronLeft,
  ChevronRight,
  Plus,
  Receipt,
  Trash2,
  Wallet,
} from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import type { Transaction } from "@/db/schema";
import { refreshAll, transactionApi, useTransactions } from "@/lib/api";
import { cn, dayLabel, formatMonth, formatRupiah } from "@/lib/format";
import { Button, Card, ConfirmDialog, EmptyState, IconButton, Segmented } from "@/components/ui";
import { TransactionModal } from "@/components/transaction-modal";
import { CountUpRupiah } from "@/components/count-up";

type Filter = "semua" | "income" | "expense";

function MiniStat({
  label,
  value,
  tone,
  suffix,
}: {
  label: string;
  value: number;
  tone: "green" | "rose" | "dark";
  suffix?: string;
}) {
  return (
    <Card className="flex-1 p-4 sm:p-5">
      <p className="text-[13px] font-bold text-stone-500">{label}</p>
      <p
        className={cn(
          "mt-2 text-lg font-extrabold tracking-tight sm:text-2xl",
          tone === "green" && "text-emerald-700",
          tone === "rose" && "text-rose-600",
          tone === "dark" && "text-stone-900",
        )}
      >
        {suffix}
        <CountUpRupiah value={value} />
      </p>
    </Card>
  );
}

function TransactionItem({ tx, onDelete }: { tx: Transaction; onDelete: () => void }) {
  const income = tx.type === "income";
  return (
    <motion.div
      layout
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, x: -24 }}
      className="group flex items-center gap-3 px-4 py-3 sm:px-5"
    >
      <div
        className={cn(
          "grid size-10 shrink-0 place-items-center rounded-xl",
          income ? "bg-emerald-50 text-emerald-600" : "bg-rose-50 text-rose-500",
        )}
      >
        {income ? <ArrowUpRight className="size-[18px]" /> : <ArrowDownRight className="size-[18px]" />}
      </div>
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-bold text-stone-800">{tx.note}</p>
        <p className="text-xs font-medium text-stone-400">{income ? "Pemasukan" : "Pengeluaran"}</p>
      </div>
      <p
        className={cn(
          "shrink-0 text-sm font-extrabold tabular-nums sm:text-[15px]",
          income ? "text-emerald-700" : "text-rose-600",
        )}
      >
        {income ? "+" : "−"}
        {formatRupiah(tx.amount)}
      </p>
      <IconButton
        onClick={onDelete}
        aria-label="Hapus transaksi"
        className="opacity-0 transition-opacity group-hover:opacity-100 hover:bg-rose-50 hover:text-rose-600 max-sm:opacity-100"
      >
        <Trash2 className="size-4" />
      </IconButton>
    </motion.div>
  );
}

export default function KeuanganPage() {
  const { transactions, isLoading } = useTransactions();
  const [filter, setFilter] = useState<Filter>("semua");
  const [monthOffset, setMonthOffset] = useState(0);
  const [modalOpen, setModalOpen] = useState(false);
  const [deleting, setDeleting] = useState<Transaction | null>(null);
  const [deleteBusy, setDeleteBusy] = useState(false);

  const { year, month, label } = useMemo(() => {
    const now = new Date();
    const d = new Date(now.getFullYear(), now.getMonth() + monthOffset, 1);
    return { year: d.getFullYear(), month: d.getMonth(), label: formatMonth(d.getFullYear(), d.getMonth()) };
  }, [monthOffset]);

  const inSelectedMonth = useMemo(() => {
    return transactions.filter((t) => {
      const [y, m] = t.date.split("-").map(Number);
      return y === year && m - 1 === month;
    });
  }, [transactions, year, month]);

  const monthIncome = inSelectedMonth.filter((t) => t.type === "income").reduce((s, t) => s + t.amount, 0);
  const monthExpense = inSelectedMonth.filter((t) => t.type === "expense").reduce((s, t) => s + t.amount, 0);
  const selisih = monthIncome - monthExpense;

  const filtered = useMemo(() => {
    return inSelectedMonth.filter((t) => filter === "semua" || t.type === filter);
  }, [inSelectedMonth, filter]);

  const groups = useMemo(() => {
    const map = new Map<string, Transaction[]>();
    for (const t of filtered) {
      const arr = map.get(t.date) ?? [];
      arr.push(t);
      map.set(t.date, arr);
    }
    return [...map.entries()].sort((a, b) => (a[0] < b[0] ? 1 : -1));
  }, [filtered]);

  const countIncome = inSelectedMonth.filter((t) => t.type === "income").length;
  const countExpense = inSelectedMonth.length - countIncome;

  async function confirmDelete() {
    if (!deleting) return;
    setDeleteBusy(true);
    try {
      await transactionApi.remove(deleting.id);
      toast.success("Transaksi dihapus.");
      refreshAll();
      setDeleting(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Gagal menghapus transaksi.");
    } finally {
      setDeleteBusy(false);
    }
  }

  return (
    <div className="flex flex-col gap-5">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight text-stone-900 sm:text-3xl">Keuangan</h1>
          <p className="mt-1 text-sm font-medium text-stone-500">
            Catat pemasukan dan pengeluaran tokomu.
          </p>
        </div>
        <Button onClick={() => setModalOpen(true)}>
          <Plus className="size-4" strokeWidth={2.6} />
          Catat Transaksi
        </Button>
      </div>

      {/* Navigasi bulan */}
      <div className="flex items-center justify-between rounded-2xl border border-stone-200/70 bg-white px-2 py-2 shadow-[0_1px_2px_rgba(28,25,23,0.04)]">
        <button
          onClick={() => setMonthOffset((v) => v - 1)}
          aria-label="Bulan sebelumnya"
          className="grid size-9 cursor-pointer place-items-center rounded-xl text-stone-500 transition-colors hover:bg-stone-100 hover:text-stone-900"
        >
          <ChevronLeft className="size-5" />
        </button>
        <p className="flex items-center gap-2 text-sm font-extrabold tracking-tight text-stone-900">
          <Wallet className="size-4 text-emerald-700" />
          {label}
        </p>
        <button
          onClick={() => setMonthOffset((v) => Math.min(0, v + 1))}
          disabled={monthOffset >= 0}
          aria-label="Bulan berikutnya"
          className="grid size-9 cursor-pointer place-items-center rounded-xl text-stone-500 transition-colors hover:bg-stone-100 hover:text-stone-900 disabled:pointer-events-none disabled:opacity-30"
        >
          <ChevronRight className="size-5" />
        </button>
      </div>

      {/* Statistik bulan */}
      <div className="flex flex-col gap-3 sm:flex-row sm:gap-4">
        <MiniStat label="Pemasukan" value={monthIncome} tone="green" />
        <MiniStat label="Pengeluaran" value={monthExpense} tone="rose" />
        <MiniStat
          label="Selisih"
          value={Math.abs(selisih)}
          tone={selisih < 0 ? "rose" : "dark"}
          suffix={selisih < 0 ? "−" : ""}
        />
      </div>

      {/* Filter */}
      <div className="flex items-center justify-between gap-3">
        <Segmented<Filter>
          id="filter-keuangan"
          value={filter}
          onChange={setFilter}
          options={[
            { value: "semua", label: "Semua", count: inSelectedMonth.length },
            { value: "income", label: "Pemasukan", icon: ArrowUpRight, count: countIncome },
            { value: "expense", label: "Pengeluaran", icon: ArrowDownRight, count: countExpense },
          ]}
        />
      </div>

      {/* Daftar transaksi */}
      <Card className="overflow-hidden p-0">
        {isLoading ? (
          <div className="space-y-3 p-5">
            {[0, 1, 2, 3].map((i) => (
              <div key={i} className="h-14 animate-pulse rounded-xl bg-stone-100" />
            ))}
          </div>
        ) : groups.length === 0 ? (
          <EmptyState
            icon={Receipt}
            title="Belum ada transaksi"
            message={`Belum ada ${filter === "expense" ? "pengeluaran" : filter === "income" ? "pemasukan" : "transaksi"} di ${label}. Tekan tombol Catat Transaksi untuk menambah.`}
            action={
              <Button size="sm" onClick={() => setModalOpen(true)}>
                <Plus className="size-4" />
                Catat Transaksi
              </Button>
            }
          />
        ) : (
          groups.map(([date, txs]) => (
            <div key={date}>
              <div className="sticky flex items-center justify-between border-y border-stone-100 bg-stone-50/80 px-4 py-2 sm:px-5">
                <p className="text-xs font-extrabold uppercase tracking-wide text-stone-400">{dayLabel(date)}</p>
                <p className="text-xs font-bold text-stone-400 tabular-nums">
                  {txs.length} transaksi
                </p>
              </div>
              <div className="divide-y divide-stone-50">
                <AnimatePresence initial={false}>
                  {txs.map((t) => (
                    <TransactionItem key={t.id} tx={t} onDelete={() => setDeleting(t)} />
                  ))}
                </AnimatePresence>
              </div>
            </div>
          ))
        )}
      </Card>

      <TransactionModal open={modalOpen} onClose={() => setModalOpen(false)} />
      <ConfirmDialog
        open={Boolean(deleting)}
        onClose={() => setDeleting(null)}
        onConfirm={confirmDelete}
        loading={deleteBusy}
        title="Hapus Transaksi"
        message={`Yakin mau hapus "${deleting?.note}" senilai ${deleting ? formatRupiah(deleting.amount) : ""}? Data ini tidak bisa dikembalikan.`}
      />
    </div>
  );
}
