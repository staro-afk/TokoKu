import { asc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { products, transactions } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { daysUntil, toISODate } from "@/lib/format";

export const dynamic = "force-dynamic";

const EXPIRING_WINDOW_DAYS = 14;

export async function GET() {
  const { user, error } = await requireUser();
  if (error) return error;

  const [allProducts, allTransactions] = await Promise.all([
    db.select().from(products).where(eq(products.userId, user.id)).orderBy(asc(products.name)),
    db.select().from(transactions).where(eq(transactions.userId, user.id)),
  ]);

  const now = new Date();
  const monthStart = toISODate(new Date(now.getFullYear(), now.getMonth(), 1));
  const monthEnd = toISODate(new Date(now.getFullYear(), now.getMonth() + 1, 0));

  let monthIncome = 0;
  let monthExpense = 0;
  let totalIncome = 0;
  let totalExpense = 0;

  for (const t of allTransactions) {
    if (t.type === "income") totalIncome += t.amount;
    else totalExpense += t.amount;
    if (t.date >= monthStart && t.date <= monthEnd) {
      if (t.type === "income") monthIncome += t.amount;
      else monthExpense += t.amount;
    }
  }

  const lowStock = allProducts
    .filter((p) => p.stock <= p.minStock)
    .sort((a, b) => a.stock - b.stock);

  const expiring = allProducts
    .filter((p) => p.expiryDate !== null)
    .map((p) => ({ ...p, daysLeft: daysUntil(p.expiryDate as string) }))
    .filter((p) => p.daysLeft <= EXPIRING_WINDOW_DAYS)
    .sort((a, b) => a.daysLeft - b.daysLeft);

  const recent = [...allTransactions]
    .sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : b.id - a.id))
    .slice(0, 6);

  const stockValue = allProducts.reduce((sum, p) => sum + p.sellPrice * p.stock, 0);

  return NextResponse.json({
    monthIncome,
    monthExpense,
    balance: totalIncome - totalExpense,
    totalProducts: allProducts.length,
    stockValue,
    lowStockCount: lowStock.length,
    expiringCount: expiring.length,
    lowStock: lowStock.slice(0, 5),
    expiring: expiring.slice(0, 5),
    recent,
  });
}
