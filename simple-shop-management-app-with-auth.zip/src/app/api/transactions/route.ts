import { desc, eq } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { transactions } from "@/db/schema";
import { requireUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const { user, error } = await requireUser();
  if (error) return error;

  const rows = await db
    .select()
    .from(transactions)
    .where(eq(transactions.userId, user.id))
    .orderBy(desc(transactions.date), desc(transactions.id));
  return NextResponse.json(rows);
}

export async function POST(req: NextRequest) {
  const { user, error } = await requireUser();
  if (error) return error;

  try {
    const body = await req.json();

    const type = body?.type === "expense" ? "expense" : body?.type === "income" ? "income" : null;
    if (!type) {
      return NextResponse.json({ error: "Jenis transaksi tidak valid." }, { status: 400 });
    }

    const amount = Number(body?.amount);
    if (!Number.isFinite(amount) || amount <= 0) {
      return NextResponse.json({ error: "Jumlah harus lebih dari nol." }, { status: 400 });
    }

    const note = String(body?.note ?? "").trim();
    if (!note) {
      return NextResponse.json({ error: "Keterangan wajib diisi." }, { status: 400 });
    }

    const date = typeof body?.date === "string" && body.date ? body.date : null;
    if (!date) {
      return NextResponse.json({ error: "Tanggal wajib diisi." }, { status: 400 });
    }

    const [created] = await db
      .insert(transactions)
      .values({
        userId: user.id,
        type,
        amount: Math.round(amount),
        note,
        date,
      })
      .returning();

    return NextResponse.json(created, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Gagal menyimpan transaksi." }, { status: 500 });
  }
}
