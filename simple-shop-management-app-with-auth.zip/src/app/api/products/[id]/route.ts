import { and, eq } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { products } from "@/db/schema";
import { requireUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

function parseId(raw: string) {
  const id = Number(raw);
  return Number.isInteger(id) && id > 0 ? id : null;
}

function toNonNegativeInt(value: unknown) {
  const n = Number(value);
  if (!Number.isFinite(n) || n < 0) return null;
  return Math.round(n);
}

export async function PATCH(req: NextRequest, ctx: Ctx) {
  const { user, error } = await requireUser();
  if (error) return error;

  const { id: raw } = await ctx.params;
  const id = parseId(raw);
  if (!id) return NextResponse.json({ error: "ID tidak valid." }, { status: 400 });

  try {
    const body = await req.json();
    const patch: Record<string, unknown> = {};

    if (typeof body?.name === "string") {
      const name = body.name.trim();
      if (!name) return NextResponse.json({ error: "Nama barang tidak boleh kosong." }, { status: 400 });
      patch.name = name;
    }
    if (typeof body?.category === "string") patch.category = body.category.trim() || "Lainnya";
    if (body?.sellPrice !== undefined) {
      const v = toNonNegativeInt(body.sellPrice);
      if (v === null) return NextResponse.json({ error: "Harga tidak valid." }, { status: 400 });
      patch.sellPrice = v;
    }
    if (body?.stock !== undefined) {
      const v = toNonNegativeInt(body.stock);
      if (v === null) return NextResponse.json({ error: "Stok tidak valid." }, { status: 400 });
      patch.stock = v;
    }
    if (body?.minStock !== undefined) {
      const v = toNonNegativeInt(body.minStock);
      if (v === null) return NextResponse.json({ error: "Stok minimum tidak valid." }, { status: 400 });
      patch.minStock = v;
    }
    if (body?.expiryDate !== undefined) {
      patch.expiryDate = typeof body.expiryDate === "string" && body.expiryDate ? body.expiryDate : null;
    }

    patch.updatedAt = new Date();

    const [updated] = await db
      .update(products)
      .set(patch)
      .where(and(eq(products.id, id), eq(products.userId, user.id)))
      .returning();
    if (!updated) return NextResponse.json({ error: "Barang tidak ditemukan." }, { status: 404 });
    return NextResponse.json(updated);
  } catch {
    return NextResponse.json({ error: "Gagal mengubah barang." }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  const { user, error } = await requireUser();
  if (error) return error;

  const { id: raw } = await ctx.params;
  const id = parseId(raw);
  if (!id) return NextResponse.json({ error: "ID tidak valid." }, { status: 400 });

  const [deleted] = await db
    .delete(products)
    .where(and(eq(products.id, id), eq(products.userId, user.id)))
    .returning({ id: products.id });
  if (!deleted) return NextResponse.json({ error: "Barang tidak ditemukan." }, { status: 404 });
  return NextResponse.json({ ok: true });
}
