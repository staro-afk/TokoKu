import { asc, eq } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { products } from "@/db/schema";
import { requireUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const { user, error } = await requireUser();
  if (error) return error;

  const rows = await db
    .select()
    .from(products)
    .where(eq(products.userId, user.id))
    .orderBy(asc(products.name));
  return NextResponse.json(rows);
}

function toNonNegativeInt(value: unknown, fallback = 0) {
  const n = Number(value);
  if (!Number.isFinite(n) || n < 0) return fallback;
  return Math.round(n);
}

export async function POST(req: NextRequest) {
  const { user, error } = await requireUser();
  if (error) return error;

  try {
    const body = await req.json();

    const name = String(body?.name ?? "").trim();
    if (!name) {
      return NextResponse.json({ error: "Nama barang wajib diisi." }, { status: 400 });
    }

    const category = String(body?.category ?? "").trim() || "Lainnya";
    const sellPrice = toNonNegativeInt(body?.sellPrice);
    const stock = toNonNegativeInt(body?.stock);
    const minStock = toNonNegativeInt(body?.minStock, 5);
    const expiryRaw = typeof body?.expiryDate === "string" && body.expiryDate ? body.expiryDate : null;

    const [created] = await db
      .insert(products)
      .values({
        userId: user.id,
        name,
        category,
        sellPrice,
        stock,
        minStock,
        expiryDate: expiryRaw,
      })
      .returning();

    return NextResponse.json(created, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Gagal menyimpan barang." }, { status: 500 });
  }
}
