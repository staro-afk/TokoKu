"use client";

import { motion } from "framer-motion";
import {
  ArrowDownRight,
  ArrowUpRight,
  CalendarClock,
  ChevronRight,
  Package,
  PackagePlus,
  ShoppingBag,
  ShoppingCart,
  Wallet,
} from "lucide-react";
import Link from "next/link";
import { useState } from "react";
import { toast } from "sonner";
import type { Product, Transaction } from "@/db/schema";
import { type ExpiringProduct, EXPIRING_WINDOW_DAYS, expiryDays, isLowStock, productApi, refreshAll, transactionApi, useStats } from "@/lib/api";
import {
  cn,
  expiryLabel,
  formatRupiah,
  formatShortDate,
  todayISO,
} from "@/lib/format";
import { QuickNumpad } from "@/components/quick-numpad";
import { TransactionModal } from "@/components/transaction-modal";
import { ProductModal } from "@/components/product-modal";
import { CountUpRupiah } from "@/components/count-up";

/* ---- animation ---- */
const container = { hidden: {}, show: { transition: { staggerChildren: 0.05 } } };
const item = {
  hidden: { opacity: 0, y: 16 },
  show: { opacity: 1, y: 0, transition: { type: "spring" as const, stiffness: 280, damping: 28 } },
};

/* ---- Tombol aksi cepat atas ---- */
function QuickAction({
  icon: Icon,
  label,
  onClick,
  accent,
}: {
  icon: typeof Package;
  label: string;
  onClick: () => void;
  accent?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "flex flex-col items-center gap-2 rounded-2xl p-4 text-center transition-all active:scale-95 cursor-pointer w-full",
        accent
          ? "bg-emerald-700 text-white shadow-[0_8px_20px_-8px_rgba(6,78,59,0.55)]"
          : "bg-white text-stone-700 shadow-sm ring-1 ring-stone-200",
      )}
    >
      <div
        className={cn(
          "grid size-11 place-items-center rounded-xl",
          accent ? "bg-white/20" : "bg-stone-100",
        )}
      >
        <Icon className={cn("size-5", accent ? "text-white" : "text-stone-600")} strokeWidth={2.2} />
      </div>
      <span className={cn("text-[13px] font-bold", accent ? "text-emerald-100" : "text-stone-700")}>
        {label}
      </span>
    </button>
  );
}

/* ---- Kartu "Perlu dicek" ---- */
function AlertCard({
  product,
  onJual,
  onBeli,
}: {
  product: (Product | ExpiringProduct) & { daysLeft?: number };
  onJual: () => void;
  onBeli: () => void;
}) {
  const low = isLowStock(product);
  const expDays = expiryDays(product);
  const expired = expDays !== null && expDays < 0;
  const expiringSoon = expDays !== null && expDays >= 0 && expDays <= EXPIRING_WINDOW_DAYS;

  return (
    <div className="rounded-2xl bg-white p-4 shadow-sm ring-1 ring-stone-200">
      {/* Baris atas: nama + stok */}
      <div className="flex items-start justify-between gap-2">
        <p className="font-extrabold text-stone-900 text-[15px] leading-snug flex-1 pr-1">{product.name}</p>
        <span className="text-2xl font-black text-stone-700 tabular-nums shrink-0">{product.stock}</span>
      </div>

      {/* Harga + badge status */}
      <div className="mt-1.5 flex flex-wrap items-center gap-2">
        <span className="text-sm font-bold text-stone-500">{formatRupiah(product.sellPrice)}</span>
        {expired && (
          <>
            <span className="rounded-full bg-red-100 px-2.5 py-0.5 text-xs font-bold text-red-600">
              Sudah kedaluwarsa
            </span>
            <span className="text-xs font-semibold text-stone-400">{expiryLabel(expDays!)}</span>
          </>
        )}
        {expiringSoon && (
          <>
            <span
              className={cn(
                "rounded-full px-2.5 py-0.5 text-xs font-bold",
                (expDays ?? 99) <= 3
                  ? "bg-red-100 text-red-600"
                  : (expDays ?? 99) <= 7
                  ? "bg-rose-100 text-rose-600"
                  : "bg-amber-100 text-amber-700",
              )}
            >
              {(expDays ?? 99) <= 3 ? "Segera kedaluwarsa" : "Mau kedaluwarsa"}
            </span>
            <span className="text-xs font-semibold text-stone-400">{expiryLabel(expDays!)}</span>
          </>
        )}
        {low && !expired && !expiringSoon && (
          <span className="rounded-full bg-amber-100 px-2.5 py-0.5 text-xs font-bold text-amber-700">
            Mau habis
          </span>
        )}
      </div>

      {/* Tombol aksi */}
      <div className="mt-3 grid grid-cols-2 gap-2">
        <button
          onClick={onBeli}
          className="flex h-10 items-center justify-center gap-1.5 rounded-xl border border-stone-200 bg-white text-sm font-bold text-stone-700 transition-all active:scale-[0.97] hover:bg-stone-50 cursor-pointer"
        >
          <ShoppingCart className="size-4" />
          Beli stok
        </button>
        <button
          onClick={onJual}
          className="flex h-10 items-center justify-center gap-1.5 rounded-xl bg-emerald-50 text-sm font-bold text-emerald-700 transition-all active:scale-[0.97] hover:bg-emerald-100 cursor-pointer"
        >
          <ShoppingBag className="size-4" />
          Jual
        </button>
      </div>
    </div>
  );
}

/* ---- Transaksi terakhir row ---- */
function TxRow({ tx }: { tx: Transaction }) {
  const income = tx.type === "income";
  return (
    <div className="flex items-center gap-3 py-2.5">
      <div
        className={cn(
          "grid size-9 shrink-0 place-items-center rounded-xl",
          income ? "bg-emerald-50 text-emerald-600" : "bg-rose-50 text-rose-500",
        )}
      >
        {income ? <ArrowUpRight className="size-4" /> : <ArrowDownRight className="size-4" />}
      </div>
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-bold text-stone-800">{tx.note}</p>
        <p className="text-xs text-stone-400 font-medium">{formatShortDate(tx.date)}</p>
      </div>
      <p className={cn("text-sm font-extrabold tabular-nums shrink-0", income ? "text-emerald-700" : "text-rose-600")}>
        {income ? "+" : "−"}{formatRupiah(tx.amount)}
      </p>
    </div>
  );
}

/* ---- Halaman utama ---- */
export default function BerandaPage() {
  const { stats, isLoading } = useStats();

  // Numpad state
  const [numpad, setNumpad] = useState<{
    open: boolean;
    mode: "jual" | "beli";
    product: Product | null;
  }>({ open: false, mode: "jual", product: null });

  // Modal tambah barang cepat
  const [barangModal, setBarangModal] = useState(false);
  // Modal catat transaksi kas
  const [kasModal, setKasModal] = useState(false);

  function openJual(p: Product) {
    setNumpad({ open: true, mode: "jual", product: p });
  }
  function openBeli(p: Product) {
    setNumpad({ open: true, mode: "beli", product: p });
  }

  async function handleNumpadConfirm(qty: number, total: number, customNominal?: number) {
    const p = numpad.product;
    if (!p) return;

    if (numpad.mode === "jual") {
      // Kurangi stok + catat pemasukan
      const newStock = Math.max(0, p.stock - qty);
      await Promise.all([
        productApi.update(p.id, { stock: newStock }),
        transactionApi.create({
          type: "income",
          amount: customNominal ?? total,
          note: `Jual ${p.name}${qty > 1 ? ` ×${qty}` : ""}`,
          date: todayISO(),
        }),
      ]);
      toast.success(`✅ Penjualan ${p.name} tercatat!`);
    } else {
      // Tambah stok + catat pengeluaran
      const newStock = p.stock + qty;
      const nominal = total > 0 ? total : qty * p.sellPrice;
      await Promise.all([
        productApi.update(p.id, { stock: newStock }),
        transactionApi.create({
          type: "expense",
          amount: nominal,
          note: `Beli stok ${p.name} ×${qty}`,
          date: todayISO(),
        }),
      ]);
      toast.success(`📦 Stok ${p.name} bertambah jadi ${newStock}!`);
    }

    refreshAll();
    setNumpad((v) => ({ ...v, open: false }));
  }

  // Gabung list "perlu dicek": low stock + expiring
  const needsAttention = (() => {
    if (!stats) return [];
    const seen = new Set<number>();
    const result: (Product & { daysLeft?: number })[] = [];
    for (const p of stats.expiring) {
      seen.add(p.id);
      result.push(p);
    }
    for (const p of stats.lowStock) {
      if (!seen.has(p.id)) {
        seen.add(p.id);
        result.push(p);
      }
    }
    return result;
  })();

  const selisih = stats ? stats.monthIncome - stats.monthExpense : 0;

  return (
    <>
      <motion.div variants={container} initial="hidden" animate="show" className="flex flex-col gap-5">

        {/* Kartu kas ringkas */}
        <motion.div variants={item}>
          <div className="rounded-3xl bg-emerald-700 px-5 py-5 text-white shadow-[0_12px_32px_-12px_rgba(6,78,59,0.6)]">
            <p className="text-[13px] font-bold text-emerald-300 uppercase tracking-wide">Bulan ini</p>
            <div className="mt-2 flex items-end justify-between gap-4">
              <div>
                <p className="text-[13px] text-emerald-300 font-semibold">Pemasukan</p>
                <p className="text-2xl font-black tabular-nums">
                  <CountUpRupiah value={stats?.monthIncome ?? 0} />
                </p>
              </div>
              <div className="text-right">
                <p className="text-[13px] text-emerald-300 font-semibold">Pengeluaran</p>
                <p className="text-xl font-black tabular-nums text-emerald-100">
                  <CountUpRupiah value={stats?.monthExpense ?? 0} />
                </p>
              </div>
            </div>
            <div className="mt-3 border-t border-emerald-600 pt-3 flex items-center justify-between">
              <p className="text-xs font-semibold text-emerald-300">Selisih</p>
              <p className={cn("text-lg font-black tabular-nums", selisih < 0 ? "text-rose-300" : "text-white")}>
                {selisih < 0 ? "−" : "+"}<CountUpRupiah value={Math.abs(selisih)} />
              </p>
            </div>
          </div>
        </motion.div>

        {/* 3 tombol aksi cepat */}
        <motion.div variants={item} className="grid grid-cols-3 gap-3">
          <QuickAction
            icon={PackagePlus}
            label="Barang"
            onClick={() => setBarangModal(true)}
          />
          <QuickAction
            icon={ShoppingBag}
            label="Jual"
            accent
            onClick={() => {
              // Buka halaman barang untuk pilih produk yg mau dijual
              window.location.href = "/barang";
            }}
          />
          <QuickAction
            icon={Wallet}
            label="Catat"
            onClick={() => setKasModal(true)}
          />
        </motion.div>

        {/* Perlu dicek */}
        {(isLoading || needsAttention.length > 0) && (
          <motion.div variants={item} className="flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-extrabold tracking-tight text-stone-900">Perlu dicek</h2>
              <Link
                href="/barang?filter=menipis"
                className="flex items-center gap-0.5 text-sm font-bold text-emerald-700 hover:text-emerald-900"
              >
                Lihat semua
                <ChevronRight className="size-4" />
              </Link>
            </div>

            {isLoading ? (
              [0, 1, 2].map((i) => (
                <div key={i} className="h-28 animate-pulse rounded-2xl bg-white" />
              ))
            ) : (
              needsAttention.map((p) => (
                <AlertCard
                  key={p.id}
                  product={p}
                  onJual={() => openJual(p)}
                  onBeli={() => openBeli(p)}
                />
              ))
            )}
          </motion.div>
        )}

        {/* Transaksi terakhir */}
        <motion.div variants={item} className="flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-extrabold tracking-tight text-stone-900">Transaksi terakhir</h2>
            <Link
              href="/keuangan"
              className="flex items-center gap-0.5 text-sm font-bold text-emerald-700 hover:text-emerald-900"
            >
              Lihat semua
              <ChevronRight className="size-4" />
            </Link>
          </div>

          <div className="rounded-2xl bg-white px-4 shadow-sm ring-1 ring-stone-200">
            {isLoading ? (
              <div className="space-y-3 py-4">
                {[0, 1, 2].map((i) => (
                  <div key={i} className="h-10 animate-pulse rounded-xl bg-stone-100" />
                ))}
              </div>
            ) : stats && stats.recent.length > 0 ? (
              <div className="divide-y divide-stone-100">
                {stats.recent.map((t) => (
                  <TxRow key={t.id} tx={t} />
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center gap-2 py-10 text-center">
                <div className="grid size-12 place-items-center rounded-2xl bg-stone-100 text-stone-400">
                  <Wallet className="size-6" />
                </div>
                <p className="text-sm font-bold text-stone-600">Belum ada transaksi</p>
                <p className="text-xs text-stone-400">Tekan Catat untuk mulai mencatat kas.</p>
              </div>
            )}
          </div>
        </motion.div>

        {/* Kosong jika tidak ada yang perlu dicek dan tidak ada transaksi */}
        {!isLoading && needsAttention.length === 0 && stats && stats.recent.length === 0 && (
          <motion.div variants={item} className="py-6 text-center">
            <div className="inline-flex flex-col items-center gap-2">
              <div className="grid size-14 place-items-center rounded-2xl bg-emerald-50 text-emerald-500">
                <CalendarClock className="size-7" />
              </div>
              <p className="font-bold text-stone-700">Semua aman!</p>
              <p className="text-sm text-stone-400">Tidak ada barang yang perlu dicek hari ini.</p>
            </div>
          </motion.div>
        )}

      </motion.div>

      {/* Numpad sheet */}
      {numpad.product && (
        <QuickNumpad
          open={numpad.open}
          mode={numpad.mode}
          productName={numpad.product.name}
          hargaSatuan={numpad.product.sellPrice}
          stokSaat={numpad.product.stock}
          onClose={() => setNumpad((v) => ({ ...v, open: false }))}
          onConfirm={handleNumpadConfirm}
        />
      )}

      {/* Modal tambah barang */}
      <ProductModal open={barangModal} onClose={() => setBarangModal(false)} product={null} />

      {/* Modal catat kas */}
      <TransactionModal open={kasModal} onClose={() => setKasModal(false)} />
    </>
  );
}
