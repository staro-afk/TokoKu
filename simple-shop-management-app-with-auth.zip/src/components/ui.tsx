"use client";

import { AnimatePresence, motion } from "framer-motion";
import { AlertTriangle, X, type LucideIcon } from "lucide-react";
import { useEffect, type ButtonHTMLAttributes, type ReactNode } from "react";
import { cn } from "@/lib/format";

/* ---------------- Button ---------------- */

type ButtonVariant = "primary" | "soft" | "ghost" | "danger" | "outline";

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: ButtonVariant;
  size?: "sm" | "md";
};

const buttonVariants: Record<ButtonVariant, string> = {
  primary:
    "bg-emerald-700 text-white shadow-[0_1px_0_rgba(0,0,0,0.05),0_4px_14px_-4px_rgba(6,78,59,0.5)] hover:bg-emerald-800 active:bg-emerald-900",
  soft: "bg-emerald-50 text-emerald-800 hover:bg-emerald-100 active:bg-emerald-100",
  ghost: "bg-transparent text-stone-600 hover:bg-stone-100 active:bg-stone-200",
  outline:
    "border border-stone-200 bg-white text-stone-700 hover:border-stone-300 hover:bg-stone-50",
  danger: "bg-rose-600 text-white hover:bg-rose-700 active:bg-rose-800",
};

export function Button({ variant = "primary", size = "md", className, ...props }: ButtonProps) {
  return (
    <button
      className={cn(
        "inline-flex select-none items-center justify-center gap-2 rounded-xl font-semibold transition-all duration-150",
        "focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-emerald-600",
        "disabled:pointer-events-none disabled:opacity-50 cursor-pointer active:scale-[0.98]",
        size === "sm" ? "h-9 px-3 text-[13px]" : "h-11 px-5 text-sm",
        buttonVariants[variant],
        className,
      )}
      {...props}
    />
  );
}

/* ---------------- IconButton ---------------- */

export function IconButton({
  className,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      className={cn(
        "grid size-9 place-items-center rounded-lg text-stone-400 transition-colors hover:bg-stone-100 hover:text-stone-700 cursor-pointer disabled:opacity-40 disabled:pointer-events-none",
        className,
      )}
      {...props}
    />
  );
}

/* ---------------- Badge ---------------- */

type BadgeTone = "green" | "amber" | "rose" | "stone" | "red";

const badgeTones: Record<BadgeTone, string> = {
  green: "bg-emerald-50 text-emerald-700 ring-emerald-600/15",
  amber: "bg-amber-50 text-amber-700 ring-amber-600/20",
  rose: "bg-rose-50 text-rose-700 ring-rose-600/15",
  red: "bg-red-100 text-red-700 ring-red-600/20",
  stone: "bg-stone-100 text-stone-600 ring-stone-500/10",
};

export function Badge({
  tone = "stone",
  children,
  className,
}: {
  tone?: BadgeTone;
  children: ReactNode;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 whitespace-nowrap rounded-full px-2.5 py-1 text-xs font-semibold ring-1 ring-inset",
        badgeTones[tone],
        className,
      )}
    >
      {children}
    </span>
  );
}

/* ---------------- Segmented ---------------- */

export type SegmentedOption<T extends string> = {
  value: T;
  label: string;
  icon?: LucideIcon;
  count?: number;
};

export function Segmented<T extends string>({
  options,
  value,
  onChange,
  id,
}: {
  options: SegmentedOption<T>[];
  value: T;
  onChange: (v: T) => void;
  id: string;
}) {
  return (
    <div className="flex w-fit max-w-full items-center gap-0.5 overflow-x-auto rounded-xl bg-stone-100 p-1">
      {options.map((opt) => {
        const active = value === opt.value;
        const Icon = opt.icon;
        return (
          <button
            key={opt.value}
            onClick={() => onChange(opt.value)}
            className={cn(
              "relative flex h-8 shrink-0 cursor-pointer items-center gap-1.5 rounded-lg px-3 text-[13px] font-semibold transition-colors",
              active ? "text-stone-900" : "text-stone-500 hover:text-stone-700",
            )}
          >
            {active && (
              <motion.span
                layoutId={`segmented-${id}`}
                className="absolute inset-0 rounded-lg bg-white shadow-sm ring-1 ring-stone-900/5"
                transition={{ type: "spring", stiffness: 500, damping: 38 }}
              />
            )}
            <span className="relative flex items-center gap-1.5">
              {Icon ? <Icon className="size-3.5" /> : null}
              {opt.label}
              {typeof opt.count === "number" && (
                <span
                  className={cn(
                    "rounded-full px-1.5 text-[11px] font-bold tabular-nums",
                    active ? "bg-stone-900 text-white" : "bg-stone-200 text-stone-500",
                  )}
                >
                  {opt.count}
                </span>
              )}
            </span>
          </button>
        );
      })}
    </div>
  );
}

/* ---------------- Modal ---------------- */

export function Modal({
  open,
  onClose,
  title,
  subtitle,
  children,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  subtitle?: string;
  children: ReactNode;
}) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-50 grid place-items-end sm:place-items-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <motion.button
            aria-label="Tutup"
            className="absolute inset-0 bg-stone-950/45 backdrop-blur-[3px]"
            onClick={onClose}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          />
          <motion.div
            role="dialog"
            aria-modal="true"
            className="relative max-h-[92dvh] w-full overflow-y-auto rounded-t-3xl bg-white p-6 shadow-2xl sm:m-4 sm:max-w-md sm:rounded-3xl"
            initial={{ opacity: 0, y: 48, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 32, scale: 0.98 }}
            transition={{ type: "spring", stiffness: 380, damping: 34 }}
          >
            <div className="mb-5 flex items-start justify-between gap-4">
              <div>
                <h2 className="text-lg font-bold tracking-tight text-stone-900">{title}</h2>
                {subtitle && <p className="mt-0.5 text-sm text-stone-500">{subtitle}</p>}
              </div>
              <IconButton onClick={onClose} aria-label="Tutup">
                <X className="size-5" />
              </IconButton>
            </div>
            {children}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

/* ---------------- ConfirmDialog ---------------- */

export function ConfirmDialog({
  open,
  onClose,
  onConfirm,
  title,
  message,
  confirmLabel = "Hapus",
  loading,
}: {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: string;
  confirmLabel?: string;
  loading?: boolean;
}) {
  return (
    <Modal open={open} onClose={onClose} title={title}>
      <div className="flex items-start gap-3">
        <div className="grid size-10 shrink-0 place-items-center rounded-full bg-rose-50 text-rose-600">
          <AlertTriangle className="size-5" />
        </div>
        <p className="pt-1.5 text-sm leading-relaxed text-stone-600">{message}</p>
      </div>
      <div className="mt-6 flex justify-end gap-2">
        <Button variant="ghost" onClick={onClose}>
          Batal
        </Button>
        <Button variant="danger" onClick={onConfirm} disabled={loading}>
          {loading ? "Menghapus..." : confirmLabel}
        </Button>
      </div>
    </Modal>
  );
}

/* ---------------- EmptyState ---------------- */

export function EmptyState({
  icon: Icon,
  title,
  message,
  action,
}: {
  icon: LucideIcon;
  title: string;
  message: string;
  action?: ReactNode;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex flex-col items-center gap-2 px-6 py-14 text-center"
    >
      <div className="mb-1 grid size-14 place-items-center rounded-2xl bg-stone-100 text-stone-400">
        <Icon className="size-7" />
      </div>
      <p className="text-base font-bold text-stone-800">{title}</p>
      <p className="max-w-xs text-sm leading-relaxed text-stone-500">{message}</p>
      {action && <div className="mt-3">{action}</div>}
    </motion.div>
  );
}

/* ---------------- Form bits ---------------- */

export function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-[13px] font-semibold text-stone-700">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-xs text-stone-400">{hint}</span>}
    </label>
  );
}

export const inputClass =
  "h-11 w-full rounded-xl border border-stone-200 bg-white px-3.5 text-sm text-stone-900 placeholder:text-stone-400 transition-colors focus:border-emerald-600 focus:outline-none focus:ring-4 focus:ring-emerald-600/10";

export function Card({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div
      className={cn(
        "rounded-2xl border border-stone-200/70 bg-white shadow-[0_1px_2px_rgba(28,25,23,0.04),0_8px_24px_-16px_rgba(28,25,23,0.12)]",
        className,
      )}
    >
      {children}
    </div>
  );
}
