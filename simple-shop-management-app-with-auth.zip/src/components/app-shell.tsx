"use client";

import { Home, LogOut, Package, Store, Wallet } from "lucide-react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import type { ReactNode } from "react";
import { Toaster } from "sonner";
import { toast } from "sonner";
import { createClient } from "@/lib/supabase/client";
import { cn } from "@/lib/format";

const NAV = [
  { href: "/", label: "Beranda", icon: Home },
  { href: "/barang", label: "Barang", icon: Package },
  { href: "/keuangan", label: "Kas", icon: Wallet },
];

const AUTH_PATHS = ["/login", "/register"];

function Logo() {
  return (
    <div className="flex items-center gap-3">
      <div className="grid size-10 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-emerald-500 to-emerald-700 text-white shadow-[0_6px_16px_-6px_rgba(6,78,59,0.7)]">
        <Store className="size-5" strokeWidth={2.2} />
      </div>
      <div className="leading-tight">
        <p className="text-[15px] font-extrabold tracking-tight text-stone-900">TokoKu</p>
        <p className="text-xs font-medium text-stone-400">Stok & Kas Sederhana</p>
      </div>
    </div>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const isAuthPage = AUTH_PATHS.includes(pathname);

  async function handleLogout() {
    const supabase = createClient();
    await supabase.auth.signOut();
    toast.success("Berhasil keluar");
    router.push("/login");
    router.refresh();
  }

  if (isAuthPage) {
    return (
      <>
        {children}
        <Toaster
          position="top-center"
          toastOptions={{
            style: {
              borderRadius: "14px",
              border: "1px solid rgba(214,211,209,0.8)",
              background: "#fff",
              color: "#1c1917",
              boxShadow: "0 12px 32px -12px rgba(28,25,23,0.25)",
            },
          }}
        />
      </>
    );
  }

  return (
    <div className="min-h-dvh bg-[#F5F3EE]">
      {/* Sidebar desktop */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-60 flex-col border-r border-stone-200/70 bg-white/70 backdrop-blur md:flex">
        <div className="px-5 pb-6 pt-6">
          <Logo />
        </div>
        <nav className="flex flex-col gap-1 px-3">
          {NAV.map((item) => {
            const active = pathname === item.href;
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "group flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-semibold transition-colors",
                  active
                    ? "bg-emerald-700 text-white shadow-[0_8px_20px_-8px_rgba(6,78,59,0.6)]"
                    : "text-stone-500 hover:bg-stone-100 hover:text-stone-900",
                )}
              >
                <Icon
                  className={cn(
                    "size-[18px] transition-colors",
                    active ? "text-emerald-200" : "text-stone-400 group-hover:text-stone-600",
                  )}
                  strokeWidth={2.2}
                />
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="mt-auto space-y-3 px-4 pb-5">
          <div className="rounded-2xl bg-emerald-50 p-4 ring-1 ring-emerald-600/10">
            <p className="text-[13px] font-bold text-emerald-900">Tips</p>
            <p className="mt-1 text-xs leading-relaxed text-emerald-800/80">
              Tap tombol <strong>Jual</strong> di halaman Barang untuk langsung input nominal dan catat penjualan.
            </p>
          </div>
          <button
            onClick={handleLogout}
            className="flex w-full items-center gap-2.5 rounded-xl px-3.5 py-2.5 text-sm font-semibold text-stone-500 transition-colors hover:bg-rose-50 hover:text-rose-600 cursor-pointer"
          >
            <LogOut className="size-[18px]" strokeWidth={2.2} />
            Keluar
          </button>
        </div>
      </aside>

      {/* Header mobile */}
      <header className="sticky top-0 z-30 flex items-center justify-between border-b border-stone-200/60 bg-[#F5F3EE]/85 px-4 py-3 backdrop-blur md:hidden">
        <Logo />
        <button
          onClick={handleLogout}
          className="grid size-9 place-items-center rounded-lg text-stone-400 transition-colors hover:bg-stone-100 hover:text-rose-600 cursor-pointer"
          aria-label="Keluar"
        >
          <LogOut className="size-5" strokeWidth={2} />
        </button>
      </header>

      {/* Konten */}
      <main className="mx-auto w-full max-w-5xl px-4 pb-28 pt-6 sm:px-6 md:pl-64 md:pr-6 md:pt-8 lg:pr-8">
        <div className="md:mx-auto md:max-w-4xl">{children}</div>
      </main>

      {/* Bottom nav mobile */}
      <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-stone-200/70 bg-white/90 pb-[env(safe-area-inset-bottom)] backdrop-blur md:hidden">
        <div className="grid grid-cols-3">
          {NAV.map((item) => {
            const active = pathname === item.href;
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex flex-col items-center gap-1 py-2.5 text-[11px] font-bold transition-colors",
                  active ? "text-emerald-700" : "text-stone-400",
                )}
              >
                <Icon className="size-5" strokeWidth={active ? 2.4 : 2} />
                {item.label}
              </Link>
            );
          })}
        </div>
      </nav>

      <Toaster
        position="top-center"
        toastOptions={{
          style: {
            borderRadius: "14px",
            border: "1px solid rgba(214,211,209,0.8)",
            background: "#fff",
            color: "#1c1917",
            boxShadow: "0 12px 32px -12px rgba(28,25,23,0.25)",
          },
        }}
      />
    </div>
  );
}
