"use client";

import { Loader2 } from "lucide-react";
import { useEffect, useState, type FormEvent } from "react";
import { toast } from "sonner";
import type { Product } from "@/db/schema";
import { productApi, refreshAll, type ProductInput } from "@/lib/api";
import { CATEGORY_OPTIONS, cn } from "@/lib/format";
import { Button, Field, Modal, inputClass } from "@/components/ui";

export function ProductModal({
  open,
  onClose,
  product,
}: {
  open: boolean;
  onClose: () => void;
  /** Kalau diisi = mode edit */
  product: Product | null;
}) {
  const editing = Boolean(product);
  const [name, setName] = useState("");
  const [category, setCategory] = useState("");
  const [sellPrice, setSellPrice] = useState("");
  const [stock, setStock] = useState("");
  const [minStock, setMinStock] = useState("5");
  const [expiryDate, setExpiryDate] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!open) return;
    setName(product?.name ?? "");
    setCategory(product?.category ?? "");
    setSellPrice(product ? String(product.sellPrice) : "");
    setStock(product ? String(product.stock) : "");
    setMinStock(product ? String(product.minStock) : "5");
    setExpiryDate(product?.expiryDate ?? "");
    setSaving(false);
  }, [open, product]);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    const price = Number(sellPrice);
    const stok = Number(stock || "0");
    const min = Number(minStock || "0");

    if (!name.trim()) return toast.error("Nama barang wajib diisi.");
    if (!sellPrice || !Number.isFinite(price) || price < 0) return toast.error("Harga jual tidak valid.");
    if (!Number.isFinite(stok) || stok < 0) return toast.error("Stok tidak valid.");

    const input: ProductInput = {
      name: name.trim(),
      category: category.trim() || "Lainnya",
      sellPrice: Math.round(price),
      stock: Math.round(stok),
      minStock: Math.round(min),
      expiryDate: expiryDate || null,
    };

    setSaving(true);
    try {
      if (product) {
        await productApi.update(product.id, input);
        toast.success(`"${input.name}" berhasil diperbarui.`);
      } else {
        await productApi.create(input);
        toast.success(`"${input.name}" berhasil ditambahkan.`);
      }
      refreshAll();
      onClose();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Gagal menyimpan barang.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={editing ? "Ubah Barang" : "Tambah Barang"}
      subtitle={editing ? "Perbarui detail barang di tokomu." : "Catat barang baru yang dijual di tokomu."}
    >
      <form onSubmit={onSubmit} className="flex flex-col gap-4">
        <Field label="Nama barang">
          <input
            autoFocus
            className={inputClass}
            placeholder="Contoh: Indomie Goreng"
            value={name}
            onChange={(e) => setName(e.target.value)}
            maxLength={120}
          />
        </Field>

        <Field label="Kategori">
          <input
            className={inputClass}
            placeholder="Pilih atau ketik kategori"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            list="kategori-barang"
            maxLength={60}
          />
          <datalist id="kategori-barang">
            {CATEGORY_OPTIONS.map((c) => (
              <option key={c} value={c} />
            ))}
          </datalist>
        </Field>

        <div className="grid grid-cols-2 gap-3">
          <Field label="Harga jual">
            <div className="relative">
              <span className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-sm font-semibold text-stone-400">
                Rp
              </span>
              <input
                className={cn(inputClass, "pl-10 tabular-nums")}
                placeholder="0"
                inputMode="numeric"
                type="number"
                min={0}
                value={sellPrice}
                onChange={(e) => setSellPrice(e.target.value)}
              />
            </div>
          </Field>
          <Field label="Jumlah stok">
            <input
              className={cn(inputClass, "tabular-nums")}
              placeholder="0"
              inputMode="numeric"
              type="number"
              min={0}
              value={stock}
              onChange={(e) => setStock(e.target.value)}
            />
          </Field>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <Field label="Stok minimum" hint="Kamu diingatkan kalau stok sampai angka ini.">
            <input
              className={cn(inputClass, "tabular-nums")}
              inputMode="numeric"
              type="number"
              min={0}
              value={minStock}
              onChange={(e) => setMinStock(e.target.value)}
            />
          </Field>
          <Field label="Tanggal expired" hint="Boleh dikosongkan.">
            <input
              className={cn(inputClass, "[color-scheme:light]")}
              type="date"
              value={expiryDate}
              onChange={(e) => setExpiryDate(e.target.value)}
            />
          </Field>
        </div>

        <div className="mt-2 flex justify-end gap-2">
          <Button type="button" variant="ghost" onClick={onClose}>
            Batal
          </Button>
          <Button type="submit" disabled={saving}>
            {saving ? <Loader2 className="size-4 animate-spin" /> : null}
            {saving ? "Menyimpan..." : editing ? "Simpan Perubahan" : "Simpan Barang"}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
