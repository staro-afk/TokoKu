"use client";

import { AnimatePresence, motion } from "framer-motion";
import { Delete, X } from "lucide-react";
import { useEffect, useState } from "react";
import { cn } from "@/lib/format";

type NumpadMode = "jual" | "beli";

interface QuickNumpadProps {
  open: boolean;
  mode: NumpadMode;
  productName: string;
  hargaSatuan: number;
  stokSaat: number;
  onClose: () => void;
  /** Dipanggil saat konfirmasi. jumlah = qty, total = rupiah */
  onConfirm: (qty: number, total: number, customNominal?: number) => Promise<void>;
}

const PADS = ["1", "2", "3", "4", "5", "6", "7", "8", "9", ".", "0", "⌫"];

function formatAngka(raw: string): string {
  const num = parseInt(raw.replace(/\./g, ""), 10);
  if (isNaN(num)) return "0";
  return new Intl.NumberFormat("id-ID").format(num);
}

function rawToNumber(raw: string): number {
  const n = parseInt(raw.replace(/\./g, ""), 10);
  return isNaN(n) ? 0 : n;
}

export function QuickNumpad({
  open,
  mode,
  productName,
  hargaSatuan,
  stokSaat,
  onClose,
  onConfirm,
}: QuickNumpadProps) {
  // mode "jual": input qty atau nominal langsung
  // mode "beli": input qty tambahan stok
  const [inputMode, setInputMode] = useState<"qty" | "nominal">("qty");
  const [raw, setRaw] = useState(""); // string digit saja (mode nominal) atau angka biasa (mode qty)
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (open) {
      setRaw("");
      setBusy(false);
      setInputMode(mode === "jual" ? "qty" : "qty");
    }
  }, [open, mode]);

  function press(key: string) {
    if (key === "⌫") {
      setRaw((v) => v.slice(0, -1));
      return;
    }
    // nominal mode: angka saja, max 12 digit
    if (inputMode === "nominal") {
      if (key === ".") return; // skip titik di nominal
      if (raw.length >= 12) return;
      setRaw((v) => (v === "0" ? key : v + key));
      return;
    }
    // qty mode: angka saja, max 4 digit
    if (key === ".") return;
    if (raw.length >= 4) return;
    setRaw((v) => (v === "0" ? key : v + key));
  }

  const qty = rawToNumber(raw);
  const nominal = inputMode === "nominal" ? rawToNumber(raw) : qty * hargaSatuan;
  const harga = hargaSatuan;

  // Untuk tampilan
  const displayNominal = inputMode === "nominal"
    ? rawToNumber(raw)
    : qty * harga;

  const displayQty = inputMode === "qty" ? qty : (harga > 0 ? Math.round(rawToNumber(raw) / harga) : 0);

  const canConfirm = inputMode === "nominal"
    ? rawToNumber(raw) > 0
    : qty > 0;

  async function handleConfirm() {
    if (!canConfirm || busy) return;
    setBusy(true);
    try {
      if (inputMode === "nominal") {
        await onConfirm(Math.max(1, displayQty), rawToNumber(raw), rawToNumber(raw));
      } else {
        await onConfirm(qty, qty * harga);
      }
    } finally {
      setBusy(false);
    }
  }

  const isJual = mode === "jual";
  const accentCls = isJual
    ? "bg-emerald-700 text-white"
    : "bg-stone-800 text-white";
  const accentLight = isJual ? "bg-emerald-50 text-emerald-700" : "bg-stone-100 text-stone-700";

  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Backdrop */}
          <motion.div
            className="fixed inset-0 z-50 bg-stone-950/50 backdrop-blur-[2px]"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
          />

          {/* Sheet bawah */}
          <motion.div
            className="fixed inset-x-0 bottom-0 z-50 overflow-hidden rounded-t-3xl bg-[#F5F3EE] shadow-2xl"
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", stiffness: 420, damping: 40 }}
          >
            {/* Handle */}
            <div className="flex justify-center pt-3 pb-1">
              <div className="h-1 w-10 rounded-full bg-stone-300" />
            </div>

            {/* Header */}
            <div className="flex items-start justify-between px-5 pb-3 pt-2">
              <div>
                <p className="text-[13px] font-bold text-stone-400 uppercase tracking-wide">
                  {isJual ? "Jual" : "Beli Stok"}
                </p>
                <p className="mt-0.5 text-lg font-extrabold text-stone-900 leading-tight max-w-[220px]">
                  {productName}
                </p>
                <p className="text-sm text-stone-500 font-medium mt-0.5">
                  {isJual
                    ? `Harga Rp${hargaSatuan.toLocaleString("id-ID")} · Stok ${stokSaat}`
                    : `Stok saat ini: ${stokSaat}`}
                </p>
              </div>
              <button
                onClick={onClose}
                className="mt-1 grid size-9 place-items-center rounded-full bg-stone-200 text-stone-600 hover:bg-stone-300 cursor-pointer"
              >
                <X className="size-4" />
              </button>
            </div>

            {/* Toggle mode (hanya untuk jual) */}
            {isJual && (
              <div className="mx-5 mb-3 grid grid-cols-2 gap-1.5 rounded-2xl bg-stone-200 p-1.5">
                {(["qty", "nominal"] as const).map((m) => (
                  <button
                    key={m}
                    onClick={() => { setInputMode(m); setRaw(""); }}
                    className={cn(
                      "h-9 rounded-xl text-sm font-bold transition-all cursor-pointer",
                      inputMode === m
                        ? "bg-white text-stone-900 shadow"
                        : "text-stone-500 hover:text-stone-700",
                    )}
                  >
                    {m === "qty" ? "Per Satuan" : "Nominal Langsung"}
                  </button>
                ))}
              </div>
            )}

            {/* Display angka */}
            <div className="mx-5 mb-4 rounded-2xl bg-white px-5 py-4 shadow-sm ring-1 ring-stone-200">
              {inputMode === "qty" ? (
                <div className="flex items-baseline justify-between">
                  <div>
                    <p className="text-4xl font-black tracking-tight text-stone-900 tabular-nums">
                      {qty === 0 ? <span className="text-stone-300">0</span> : qty}
                    </p>
                    <p className="text-sm text-stone-400 font-semibold mt-0.5">satuan</p>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-extrabold text-stone-800 tabular-nums">
                      {qty === 0 ? (
                        <span className="text-stone-300">Rp0</span>
                      ) : (
                        `Rp${displayNominal.toLocaleString("id-ID")}`
                      )}
                    </p>
                    <p className="text-xs text-stone-400 font-semibold mt-0.5">total</p>
                  </div>
                </div>
              ) : (
                <div className="flex items-baseline justify-between">
                  <div>
                    <div className="flex items-baseline gap-1">
                      <span className="text-xl font-bold text-stone-400">Rp</span>
                      <p className="text-4xl font-black tracking-tight text-stone-900 tabular-nums">
                        {raw === "" ? (
                          <span className="text-stone-300">0</span>
                        ) : (
                          formatAngka(raw)
                        )}
                      </p>
                    </div>
                    <p className="text-sm text-stone-400 font-semibold mt-0.5">nominal</p>
                  </div>
                  {hargaSatuan > 0 && (
                    <div className="text-right">
                      <p className="text-lg font-extrabold text-stone-600 tabular-nums">
                        ≈ {displayQty} satuan
                      </p>
                      <p className="text-xs text-stone-400 font-semibold mt-0.5">perkiraan</p>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Numpad */}
            <div className="grid grid-cols-3 gap-2 px-5 pb-3">
              {PADS.map((key) => (
                <button
                  key={key}
                  onClick={() => press(key)}
                  className={cn(
                    "flex h-14 items-center justify-center rounded-2xl text-xl font-bold transition-all active:scale-95 cursor-pointer select-none",
                    key === "⌫"
                      ? "bg-stone-200 text-stone-600 hover:bg-stone-300"
                      : "bg-white text-stone-900 shadow-sm ring-1 ring-stone-200 hover:bg-stone-50 active:bg-stone-100",
                  )}
                >
                  {key === "⌫" ? <Delete className="size-5" /> : key}
                </button>
              ))}
            </div>

            {/* Konfirmasi */}
            <div className="px-5 pb-5 pt-1 pb-[max(20px,env(safe-area-inset-bottom))]">
              <button
                onClick={handleConfirm}
                disabled={!canConfirm || busy}
                className={cn(
                  "flex h-14 w-full cursor-pointer items-center justify-center rounded-2xl text-base font-extrabold transition-all active:scale-[0.98] disabled:opacity-40 disabled:pointer-events-none",
                  accentCls,
                )}
              >
                {busy
                  ? "Menyimpan..."
                  : isJual
                  ? inputMode === "nominal"
                    ? `Catat Penjualan Rp${rawToNumber(raw).toLocaleString("id-ID")}`
                    : `Jual ${qty} · Rp${displayNominal.toLocaleString("id-ID")}`
                  : `Beli ${qty} · Tambah Stok`}
              </button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
