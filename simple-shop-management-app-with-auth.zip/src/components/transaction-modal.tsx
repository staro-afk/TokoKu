"use client";

import { ArrowDownCircle, ArrowUpCircle, Loader2 } from "lucide-react";
import { useEffect, useState, type FormEvent } from "react";
import { toast } from "sonner";
import { refreshAll, transactionApi, type TransactionInput } from "@/lib/api";
import { cn, todayISO } from "@/lib/format";
import { Button, Field, Modal, inputClass } from "@/components/ui";

const QUICK_NOTES: Record<"income" | "expense", string[]> = {
  income: ["Penjualan harian", "Penjualan online", "Lainnya"],
  expense: ["Belanja stok", "Listrik & sewa", "Gaji karyawan", "Lainnya"],
};

export function TransactionModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [type, setType] = useState<"income" | "expense">("income");
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [date, setDate] = useState(todayISO());
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!open) return;
    setType("income");
    setAmount("");
    setNote("");
    setDate(todayISO());
    setSaving(false);
  }, [open]);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    const value = Number(amount);
    if (!amount || !Number.isFinite(value) || value <= 0) {
      return toast.error("Jumlah uang harus lebih dari nol.");
    }
    if (!note.trim()) return toast.error("Keterangan wajib diisi.");
    if (!date) return toast.error("Tanggal wajib diisi.");

    const input: TransactionInput = {
      type,
      amount: Math.round(value),
      note: note.trim(),
      date,
    };

    setSaving(true);
    try {
      await transactionApi.create(input);
      toast.success(type === "income" ? "Pemasukan tercatat." : "Pengeluaran tercatat.");
      refreshAll();
      onClose();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Gagal menyimpan transaksi.");
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Catat Transaksi"
      subtitle="Tambah pemasukan atau pengeluaran toko."
    >
      <form onSubmit={onSubmit} className="flex flex-col gap-4">
        {/* Toggle jenis */}
        <div className="grid grid-cols-2 gap-2 rounded-2xl bg-stone-100 p-1.5">
          {(
            [
              { value: "income", label: "Pemasukan", icon: ArrowUpCircle },
              { value: "expense", label: "Pengeluaran", icon: ArrowDownCircle },
            ] as const
          ).map((opt) => {
            const active = type === opt.value;
            const Icon = opt.icon;
            return (
              <button
                key={opt.value}
                type="button"
                onClick={() => setType(opt.value)}
                className={cn(
                  "flex h-11 cursor-pointer items-center justify-center gap-2 rounded-xl text-sm font-bold transition-all",
                  active
                    ? opt.value === "income"
                      ? "bg-emerald-700 text-white shadow"
                      : "bg-rose-600 text-white shadow"
                    : "text-stone-500 hover:text-stone-800",
                )}
              >
                <Icon className="size-4" />
                {opt.label}
              </button>
            );
          })}
        </div>

        <Field label="Jumlah">
          <div className="relative">
            <span className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-base font-bold text-stone-400">
              Rp
            </span>
            <input
              autoFocus
              className={cn(inputClass, "h-13 pl-11 text-lg font-bold tabular-nums")}
              placeholder="0"
              inputMode="numeric"
              type="number"
              min={0}
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
          </div>
        </Field>

        <Field label="Keterangan">
          <input
            className={inputClass}
            placeholder={type === "income" ? "Contoh: Penjualan hari ini" : "Contoh: Belanja stok mingguan"}
            value={note}
            onChange={(e) => setNote(e.target.value)}
            list="keterangan-transaksi"
            maxLength={200}
          />
          <datalist id="keterangan-transaksi">
            {QUICK_NOTES[type].map((n) => (
              <option key={n} value={n} />
            ))}
          </datalist>
        </Field>

        <Field label="Tanggal">
          <input
            className={cn(inputClass, "[color-scheme:light]")}
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
          />
        </Field>

        <div className="mt-2 flex justify-end gap-2">
          <Button type="button" variant="ghost" onClick={onClose}>
            Batal
          </Button>
          <Button
            type="submit"
            disabled={saving}
            className={cn(type === "expense" && "bg-rose-600 hover:bg-rose-700 active:bg-rose-800 shadow-[0_1px_0_rgba(0,0,0,0.05),0_4px_14px_-4px_rgba(190,18,60,0.5)]")}
          >
            {saving ? <Loader2 className="size-4 animate-spin" /> : null}
            {saving ? "Menyimpan..." : "Simpan Transaksi"}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
