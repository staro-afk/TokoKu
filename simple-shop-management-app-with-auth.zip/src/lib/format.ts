import clsx, { type ClassValue } from "clsx";

export function cn(...inputs: ClassValue[]) {
  return clsx(...inputs);
}

const rupiah = new Intl.NumberFormat("id-ID", {
  style: "currency",
  currency: "IDR",
  maximumFractionDigits: 0,
});

export function formatRupiah(value: number) {
  return rupiah.format(value);
}

export function formatRupiahShort(value: number) {
  const abs = Math.abs(value);
  if (abs >= 1_000_000_000) return `Rp${(value / 1_000_000_000).toLocaleString("id-ID", { maximumFractionDigits: 1 })} M`;
  if (abs >= 1_000_000) return `Rp${(value / 1_000_000).toLocaleString("id-ID", { maximumFractionDigits: 1 })} jt`;
  if (abs >= 100_000) return `Rp${Math.round(value / 1000)} rb`;
  return formatRupiah(value);
}

export function toISODate(d: Date) {
  const y = d.getFullYear();
  const m = `${d.getMonth() + 1}`.padStart(2, "0");
  const day = `${d.getDate()}`.padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function todayISO() {
  return toISODate(new Date());
}

const FULL_FORMAT = new Intl.DateTimeFormat("id-ID", {
  weekday: "long",
  day: "numeric",
  month: "long",
  year: "numeric",
});

const SHORT_FORMAT = new Intl.DateTimeFormat("id-ID", {
  day: "numeric",
  month: "short",
  year: "numeric",
});

const MONTH_FORMAT = new Intl.DateTimeFormat("id-ID", {
  month: "long",
  year: "numeric",
});

export function parseISODate(iso: string) {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(y, (m ?? 1) - 1, d ?? 1);
}

export function formatFullDate(iso: string) {
  return FULL_FORMAT.format(parseISODate(iso));
}

export function formatShortDate(iso: string) {
  return SHORT_FORMAT.format(parseISODate(iso));
}

export function formatMonth(year: number, monthIndex: number) {
  return MONTH_FORMAT.format(new Date(year, monthIndex, 1));
}

/** Jumlah hari dari sekarang sampai tanggal iso. Negatif = sudah lewat. */
export function daysUntil(iso: string) {
  const target = parseISODate(iso);
  const now = new Date();
  const start = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  return Math.round((target.getTime() - start.getTime()) / 86_400_000);
}

/** Label ramai untuk sisa hari expired. */
export function expiryLabel(days: number) {
  if (days < 0) return `Lewat ${Math.abs(days)} hari`;
  if (days === 0) return "Hari ini";
  if (days === 1) return "Besok";
  return `${days} hari lagi`;
}

/** Label tanggal untuk pengelompokan transaksi. */
export function dayLabel(iso: string) {
  const d = daysUntil(iso);
  if (d === 0) return "Hari ini";
  if (d === -1) return "Kemarin";
  return formatFullDate(iso);
}

export const CATEGORY_OPTIONS = [
  "Makanan",
  "Minuman",
  "Kebutuhan Pokok",
  "Perawatan",
  "Lainnya",
];
