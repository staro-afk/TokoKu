"use client";

import useSWR, { mutate } from "swr";
import type { Product, Transaction } from "@/db/schema";
import { daysUntil } from "@/lib/format";

const fetcher = async <T>(url: string): Promise<T> => {
  const res = await fetch(url, { cache: "no-store" });
  if (!res.ok) {
    throw new Error(await res.text());
  }
  return res.json() as Promise<T>;
};

async function sendJson<T>(url: string, method: string, body?: unknown): Promise<T> {
  const res = await fetch(url, {
    method,
    headers: { "Content-Type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  if (!res.ok) {
    let message = "Terjadi kesalahan. Coba lagi.";
    try {
      const data = await res.json();
      if (typeof data?.error === "string") message = data.error;
    } catch {
      // abaikan
    }
    throw new Error(message);
  }
  return res.json() as Promise<T>;
}

export function refreshAll() {
  mutate("/api/products");
  mutate("/api/transactions");
  mutate("/api/stats");
}

export function useProducts() {
  const swr = useSWR<Product[]>("/api/products", fetcher);
  return { ...swr, products: swr.data ?? [] };
}

export type TransactionInput = {
  type: "income" | "expense";
  amount: number;
  note: string;
  date: string;
};

export function useTransactions() {
  const swr = useSWR<Transaction[]>("/api/transactions", fetcher);
  return { ...swr, transactions: swr.data ?? [] };
}

export type ExpiringProduct = Product & { daysLeft: number };

export type Stats = {
  monthIncome: number;
  monthExpense: number;
  balance: number;
  totalProducts: number;
  stockValue: number;
  lowStockCount: number;
  expiringCount: number;
  lowStock: Product[];
  expiring: ExpiringProduct[];
  recent: Transaction[];
};

export function useStats() {
  const swr = useSWR<Stats>("/api/stats", fetcher);
  return { ...swr, stats: swr.data ?? null };
}

export type ProductInput = {
  name: string;
  category: string;
  sellPrice: number;
  stock: number;
  minStock: number;
  expiryDate: string | null;
};

export const productApi = {
  create: (input: ProductInput) => sendJson<Product>("/api/products", "POST", input),
  update: (id: number, input: Partial<ProductInput>) =>
    sendJson<Product>(`/api/products/${id}`, "PATCH", input),
  remove: (id: number) => sendJson<{ ok: boolean }>(`/api/products/${id}`, "DELETE"),
};

export const transactionApi = {
  create: (input: TransactionInput) => sendJson<Transaction>("/api/transactions", "POST", input),
  remove: (id: number) => sendJson<{ ok: boolean }>(`/api/transactions/${id}`, "DELETE"),
};

/* ---------- Predikat kecil untuk UI ---------- */

export function isLowStock(p: Product) {
  return p.stock <= p.minStock;
}

export function expiryDays(p: Product): number | null {
  if (!p.expiryDate) return null;
  return daysUntil(p.expiryDate);
}

export const EXPIRING_WINDOW_DAYS = 14;
