import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

/**
 * Ambil user yang sedang login dari session Supabase.
 * Return null jika belum login.
 */
export async function getCurrentUser() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  return user;
}

/**
 * Untuk API route: wajib login. Return user atau response 401.
 */
export async function requireUser() {
  const user = await getCurrentUser();
  if (!user) {
    return {
      user: null as null,
      error: NextResponse.json({ error: "Silakan login terlebih dahulu." }, { status: 401 }),
    };
  }
  return { user, error: null };
}
